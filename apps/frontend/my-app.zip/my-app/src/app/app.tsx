// Uncomment this line to use CSS modules
// import styles from './app.module.scss';
import { useState } from 'react';
import { postWords } from '../services/greetings';

export function App() {
  const [word1, setWord1] = useState('w1');
  const [word2, setWord2] = useState('w2');
  const submit = () => {
    console.log('submit')
    console.log(word1)
    console.log(word2)
    console.log('relationship', postWords(word1, word2))
  }
  return (
    <div>
      <div>
        <input type='text' id='word1' value={word1} onChange={(e) => setWord1(e.target.value)} />
        <input type='text' id='word2' value={word2} onChange={(e) => setWord2(e.target.value)} />
        <button type='button' onClick={submit}>send</button>
      </div>

    </div>
  );
}

export default App;
